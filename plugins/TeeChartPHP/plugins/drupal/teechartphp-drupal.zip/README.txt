$Id: README.txt,v 1.0 2012/05/08 09:19:00 steema Exp $

CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Installation

$Id: README.txt,v 1.0 2012/05/08 09:19:00 steema Exp $

INTRODUCTION
------------

Author of Drupal module:
* Josep Lluis Jorge, Steema Software (steema) http://steema.com

This module enables creating charts and graphs and insert them into your
Drupal contents.

Charts are created using Gd Graphics and PHP.

INSTALLATION
------------

1. Go to Administration -> Modules.

2. Download TeeChartPHP module from http://www.steema.us

3. Install it, enable it and save configuration.




