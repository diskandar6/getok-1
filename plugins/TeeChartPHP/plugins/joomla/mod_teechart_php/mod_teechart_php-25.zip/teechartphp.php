 <?php
/**
 * @version	$Id: teechartphp.php 1.0 2012-05-10 steema $
 * @package	Joomla
 * @subpackage	Content
 * @copyright	Copyright (C) 2012 by Steema Software SL. All rights reserved.
 * @license	Creative Commons, see license.txt
 * See COPYRIGHT.php for copyright notices and details.
 */

// includes
include_once dirname(__FILE__).'/sources/TChart.php';

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.utilities.string' );


function _generateChartPHP($num, $text) {
  $w = 400;
  $h = 300;
  $style = "Bar";
  $legend = "true";
  $view3D = "true";
  $title = "TeeChart PHP for Joomla";
  $data = "";
  $labels = "";

  preg_match_all('/"(?:\\\\.|[^\\\\"])*"|\S+/', $text, $matches);

  if (count($matches)>0)
    $params=$matches[0];
  else
    $params=array();

  $count = count($params);
  for ($p=0; $p<$count; $p++) {
    $val = explode("=", $params[$p]);
    if (count($val)==2) {
      switch ($val[0]) {
        case "title": $title=JString::str_ireplace(array('"', "'"), '', $val[1]); break;
        case "style": $style=JString::str_ireplace(array('"', "'"), '', $val[1]); break;
       case "view3D": $view3D=JString::str_ireplace(array('"', "'"), '', $val[1]); break;
       case "legend": $legend=JString::str_ireplace(array('"', "'"), '', $val[1]); break;
        case "width": $w=JString::str_ireplace(array('"', "'"), '', $val[1]); break;
       case "height": $h=JString::str_ireplace(array('"', "'"), '', $val[1]); break;
         case "data": $data=JString::str_ireplace(array('"', "'"), '', $val[1]); break;
       case "labels": $labels=JString::str_ireplace('"', '', $val[1]); break;
      }
    }
  }

  $chart = new TChart($w,$h);

  if ($title != "")
    $chart->getHeader()->setText($title);

  if ($view3D != "true")
    $chart->getAspect()->setView3D($view3D);

  if ($legend != "true")
    $chart->getLegend()->setVisible(false);

  $chart->addSeries(new $style($chart->getChart()));
  $series = $chart->getSeries(0);

  if ($data != "")
  {
    $yValues = explode(',', $data);
    $series->addArray($yValues);
  }

  if ($labels != "")
  {
    $sLabels = explode(',', $labels);
    $series->setLabels($sLabels);
  }

  $chart->render("images/chart".$num.".png");
  return '<img src="images/chart'.$num.'.png">';
}


class plgContentTeechartPHP extends JPlugin {

/**
 * Constructor
 *
 * @param object $subject The object to observe
 * @param object $params  The object that holds the plugin parameters
 * @since 1.5
 */
function plgContentTeechartPHP( &$subject, $config )
{
  parent::__construct( $subject, $config );
}

public function onContentBeforeDisplay( $context, &$article, &$params, $limitstart=0 )
{
  global $mainframe;
  //$document =& JFactory::getDocument();

  return '';
}

public function onContentPrepare($context, &$row, &$params, $page=0) {
    if (is_object($row)) {
        $text = &$row->text;
    }
    else {
      $text = &$row;
    }

    global $mainframe;

    $num = 1;

    do {
      $i = JString::strpos($text, "[phpchart");
      if ($i !== FALSE) {

        $i2 = JString::strpos($text, "]", $i+9);
        if ($i2 !== FALSE) {

          $options=JString::substr($text, $i+10, $i2-$i-1-9);

          $text = JString::substr($text, 0, $i) .' ' . _generateChartPHP($num++, $options) . ' ' .JString::substr($text, $i2+1);
        }
      }
    }
    while ($i !== FALSE);

    return true;
}

}
?>
